# Copyright (c) 2012-2016 Seafile Ltd.
import django.dispatch


avatar_updated = django.dispatch.Signal(providing_args=["user", "avatar"])