# Copyright (c) 2012-2016 Seafile Ltd.
from django.db import models

# Create your models here.
